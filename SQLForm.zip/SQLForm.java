import java.awt.event.KeyEvent;
import static java.lang.Integer.parseInt;
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Richard
 */
public class SQLForm extends javax.swing.JFrame {

private Statement stmt;

    public SQLForm() {
        initComponents();
        connect();
        StudentIDNo();
        Fetch();
    }
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
   
     public void connect(){
          try{
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL","root","JavaPrime13_DataBase");
            //Line of code to initialize connection with the server, where root is the username and blank is the password for the user
            
            //sets the statement object to command the connected SQL. The methods can now command the database this way.
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, "No SQL connection can be made","Connection error", 0);
        } catch (ClassNotFoundException ex) {
        Logger.getLogger(SQLForm.class.getName()).log(Level.SEVERE, null, ex);
    }
        
     }
  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        SearchBtn = new javax.swing.JButton();
        Student = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Addbtn = new javax.swing.JButton();
        Updatebtn = new javax.swing.JButton();
        DeleteBtn = new javax.swing.JButton();
        Newbtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        studname = new javax.swing.JTextField();
        typestud = new javax.swing.JTextField();
        course = new javax.swing.JTextField();
        section = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        StudID = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Monospaced", 1, 48)); // NOI18N
        jLabel1.setText("Student List");

        SearchBtn.setText("Search");
        SearchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBtnActionPerformed(evt);
            }
        });

        Student.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentActionPerformed(evt);
            }
        });

        jLabel2.setText("Student ID:");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Student ID", "Type of Student", "Course", "Section"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        Addbtn.setText("Add");
        Addbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddbtnActionPerformed(evt);
            }
        });

        Updatebtn.setText("Update");
        Updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdatebtnActionPerformed(evt);
            }
        });

        DeleteBtn.setText("Delete");
        DeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBtnActionPerformed(evt);
            }
        });

        Newbtn.setText("New");
        Newbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(Addbtn)
                        .addGap(18, 18, 18)
                        .addComponent(Updatebtn)
                        .addGap(18, 18, 18)
                        .addComponent(DeleteBtn)
                        .addGap(18, 18, 18)
                        .addComponent(Newbtn)))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Addbtn)
                    .addComponent(Updatebtn)
                    .addComponent(DeleteBtn)
                    .addComponent(Newbtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        jLabel3.setText("Student Name: ");

        jLabel4.setText("Course: ");

        jLabel5.setText("Type of Student: ");

        jLabel6.setText("Section:");

        studname.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                studnameInputMethodTextChanged(evt);
            }
        });
        studname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                studnameKeyPressed(evt);
            }
        });

        typestud.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                typestudKeyPressed(evt);
            }
        });

        section.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sectionActionPerformed(evt);
            }
        });

        jLabel7.setText("Student ID:");

        StudID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudIDActionPerformed(evt);
            }
        });
        StudID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                StudIDKeyPressed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(153, 153, 153));
        jLabel8.setText("* Remove the 0 from the ID");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addGap(65, 65, 65)
                                    .addComponent(section, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addGap(64, 64, 64)
                                    .addComponent(course, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(typestud, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(107, 107, 107)
                                .addComponent(StudID, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 185, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(SearchBtn)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Student, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(studname, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(107, 107, 107)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Student, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addComponent(SearchBtn)
                        .addGap(66, 66, 66))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(studname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(StudID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(2, 2, 2)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(typestud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(course, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(section, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void StudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentActionPerformed
       
        
    }//GEN-LAST:event_StudentActionPerformed

    private void SearchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBtnActionPerformed
      
        try {
        
        // TODO add your handling code here:
        String id = Student.getSelectedItem().toString();
        pst=con.prepareStatement("SELECT * FROM studentdatabase.studinfo WHERE StudID = ? ");
        pst.setString(1, id);
        rs = pst.executeQuery();
        if(rs.next()==true){
            studname.setText(rs.getString(1));
            StudID.setText(rs.getString(2));
            typestud.setText(rs.getString(3));
            course.setText(rs.getString(4));
            section.setText(rs.getString(5));
        }
        else{
             JOptionPane.showMessageDialog(this,"No Record Found!");
        }
    } catch (SQLException ex) {
        Logger.getLogger(SQLForm.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_SearchBtnActionPerformed

    private void AddbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddbtnActionPerformed
    if(studname.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Student Name is Required");
        }
        else if(StudID.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Student ID is Required");
        }
        else if(typestud.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Type of Student is Required");
        }
        else if(course.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Course is Required");
        }
        else if(section.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Section is Required");
        }
        else{
        
        try {
        // TODO add your handling code here:

            
        String name = studname.getText();
        int ID = Integer.parseInt(StudID.getText());
        String type = typestud.getText();
        String crs = course.getText();
        String sect = section.getText();
        
        pst = con.prepareStatement("INSERT INTO studentdatabase.studinfo(Name,StudID,TypeStud,Course,Section)VALUES(?,?,?,?,?)");
        pst.setString(1,name);
        pst.setInt(2,ID);
        pst.setString(3,type);
        pst.setString(4,crs);
        pst.setString(5,sect);
        
        int k =pst.executeUpdate();
        
        if (k == 1){
            JOptionPane.showMessageDialog(this,"Record Added Successfully!");
            studname.setText("");
            StudID.setText("");
            typestud.setText("");
            course.setText("");
            section.setText("");
            StudentIDNo();
            Fetch();
        }
        else{
            JOptionPane.showMessageDialog(this,"Record Failed to be Saved!");
        }
        
        
        
        
    } catch (SQLException ex) {
        Logger.getLogger(SQLForm.class.getName()).log(Level.SEVERE, null, ex);
    }
  
        }
    }//GEN-LAST:event_AddbtnActionPerformed
    private void StudentIDNo() {
        
    try {
        pst=con.prepareStatement("Select StudID FROM studentdatabase.studinfo ");
        rs=pst.executeQuery();
        Student.removeAllItems();
        while(rs.next()){
        Student.addItem(rs.getString(1));
            
        }
    } catch (SQLException ex) {
        Logger.getLogger(SQLForm.class.getName()).log(Level.SEVERE, null, ex);
    }
    }
    private void StudIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudIDActionPerformed
        
    }//GEN-LAST:event_StudIDActionPerformed

    private boolean isValidStudID(String StudID) {
    boolean isValid = true;

    try {
       
        String regex = "^[0-9]{12}$"; // Example: 12-digit numeric format

        // Check if the studID matches the expected format
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(StudID);

        isValid = matcher.matches();
    } catch (PatternSyntaxException e) {
        // Handle the exception or display an error message
        System.out.println("Invalid regex pattern: " + e.getMessage());
        isValid = false;
    }

    return isValid;
}
    private void studnameInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_studnameInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_studnameInputMethodTextChanged
    private void Fetch(){
    try {
        jTable1.setEnabled(false);
        int q;
        pst=con.prepareStatement("SELECT * FROM studentdatabase.studinfo");
        rs=pst.executeQuery();
        ResultSetMetaData rss=rs.getMetaData();
        q = rss.getColumnCount();
        DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
        df.setRowCount(0);
        while(rs.next()){
            Vector v2 = new Vector();
            for(int a = 1;a<=q;a++){
            v2.add(rs.getString("Name"));
            v2.add(rs.getString("StudID"));
            v2.add(rs.getString("TypeStud"));
            v2.add(rs.getString("Course"));
            v2.add(rs.getString("Section"));
        }
            df.addRow(v2);
        }
    } catch (SQLException ex) {
        Logger.getLogger(SQLForm.class.getName()).log(Level.SEVERE, null, ex);
    }
    }
    private void UpdatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdatebtnActionPerformed
        
        if(studname.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Student Name is Required");
        }
        else if(StudID.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Student ID is Required");
        }
        else if(typestud.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Type of Student is Required");
        }
        else if(course.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Course is Required");
        }
        else if(section.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Section is Required");
        }
        else{
        
     try {
        String name = studname.getText();
        int ID = parseInt(StudID.getText());
        String type = typestud.getText();
        String crs = course.getText();
        String sect = section.getText();
        String id = Student.getSelectedItem().toString();

        pst = con.prepareStatement("UPDATE studentdatabase.studinfo SET Name= '"+ name + "', TypeStud = '"+ type + "',Course = '"+ crs + "', Section ='"+ sect + "', StudID = '"+ ID + "' WHERE StudID = '"+ id +"'");
        int k =pst.executeUpdate();
        
        if (k == 1){
            JOptionPane.showMessageDialog(this,"Record Successfully Updated!");
            studname.setText("");
            StudID.setText("");
            typestud.setText("");
            course.setText("");
            section.setText("");
            StudentIDNo();
            Fetch();
        }
        else{
            JOptionPane.showMessageDialog(this,"Record Failed to be Updated!");
        }
        
    } catch (SQLException ex) {
        Logger.getLogger(SQLForm.class.getName()).log(Level.SEVERE, null, ex);
    }}
    }//GEN-LAST:event_UpdatebtnActionPerformed

    private void sectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sectionActionPerformed

    private void DeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBtnActionPerformed
    try {
        // TODO add your handling code here:
        String id = Student.getSelectedItem().toString();
        pst=con.prepareStatement("DELETE FROM studentdatabase.studinfo WHERE StudID=?");
        pst.setString(1, id);
        int k =pst.executeUpdate();
        if (k == 1){
            JOptionPane.showMessageDialog(this,"Record Successfully Deleted!");
            studname.setText("");
            StudID.setText("");
            typestud.setText("");
            course.setText("");
            section.setText("");
            StudentIDNo();
            Fetch();
        }
        else{
            JOptionPane.showMessageDialog(this,"Record Failed to be Deleted!");
        }
    } catch (SQLException ex) {
        Logger.getLogger(SQLForm.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_DeleteBtnActionPerformed

    private void StudIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_StudIDKeyPressed
        char c =  evt.getKeyChar();
        if(Character.isLetter(c)){
           StudID.setEditable(false);
           JOptionPane.showMessageDialog(this,"Numbers Only!");
        }
        else{
            StudID.setEditable(true);
        }
    }//GEN-LAST:event_StudIDKeyPressed

    private void studnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_studnameKeyPressed
        
      char c = evt.getKeyChar();
      int keyCode = evt.getKeyCode();
      if(Character.isLetter(c) || Character.isWhitespace(c) || Character.isISOControl(c)|| keyCode == KeyEvent.VK_CAPS_LOCK || keyCode == KeyEvent.VK_SHIFT){
          studname.setEditable(true);
      }
      else{
          studname.setEditable(false);
          JOptionPane.showMessageDialog(this,"Letters Only!");
      }
    }//GEN-LAST:event_studnameKeyPressed

    private void typestudKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_typestudKeyPressed

    }//GEN-LAST:event_typestudKeyPressed

    private void NewbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewbtnActionPerformed
            studname.setText("");
            StudID.setText("");
            typestud.setText("");
            course.setText("");
            section.setText("");
            StudentIDNo();
            Fetch();
    }//GEN-LAST:event_NewbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SQLForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SQLForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SQLForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SQLForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SQLForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Addbtn;
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JButton Newbtn;
    private javax.swing.JButton SearchBtn;
    private javax.swing.JTextField StudID;
    private javax.swing.JComboBox<String> Student;
    private javax.swing.JButton Updatebtn;
    private javax.swing.JTextField course;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField section;
    private javax.swing.JTextField studname;
    private javax.swing.JTextField typestud;
    // End of variables declaration//GEN-END:variables

    


}
